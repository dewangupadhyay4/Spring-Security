package com.security.securitypractice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.security.securitypractice.entity.Employe;
import com.security.securitypractice.entity.UserMaster;
import com.security.securitypractice.repository.EmployeRepository;

@Service
public class MyUserDetailService implements UserDetailsService{
		
	
	@Autowired
	private EmployeRepository repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Employe emp=repo.findByUsername(username);
		
		if(emp==null) {
			System.out.println("Not found");
			throw new UsernameNotFoundException("Not found");
		}
		
		return new UserMaster(emp);
	}

}
