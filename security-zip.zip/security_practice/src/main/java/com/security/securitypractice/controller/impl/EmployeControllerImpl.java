package com.security.securitypractice.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.securitypractice.controller.EmployeController;
import com.security.securitypractice.dto.EmployeDto;
import com.security.securitypractice.service.EmployeService;

@RestController
@RequestMapping("/api/employe")
public class EmployeControllerImpl implements EmployeController{
	
	@Autowired
	private EmployeService service;

	@Override
	@PostMapping("/create")
	public ResponseEntity<EmployeDto> create(@RequestBody EmployeDto dto) {
		EmployeDto creation=service.creating(dto);
		return new ResponseEntity<>(creation,HttpStatus.CREATED);
	}

	@Override
	@GetMapping("/all")
	public ResponseEntity<List<EmployeDto>> getAllOnce() {
		List<EmployeDto> list=service.gettingAll();
		return new ResponseEntity<List<EmployeDto>>(list,HttpStatus.OK);
	}

	@Override
	@GetMapping("/{id}")
	public ResponseEntity<EmployeDto> getOne( @PathVariable Long id) {
		EmployeDto one=service.gettingId(id);
		return new ResponseEntity<EmployeDto>(one,HttpStatus.OK);
	}

	@Override
	@PutMapping("/update/{id}")
	public ResponseEntity<EmployeDto> update(@PathVariable Long id,@RequestBody EmployeDto dto) {
		EmployeDto updation=service.updating(id,dto);
		return new ResponseEntity<EmployeDto>(updation,HttpStatus.OK);
	}

	@Override
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable Long id) {
		service.deleting(id);	}

}
