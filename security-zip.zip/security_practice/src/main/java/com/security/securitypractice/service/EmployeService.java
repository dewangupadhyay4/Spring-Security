package com.security.securitypractice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.security.securitypractice.dto.EmployeDto;
import com.security.securitypractice.entity.Employe;
import com.security.securitypractice.mapper.EmployeMapper;
import com.security.securitypractice.repository.EmployeRepository;

@Service
public class EmployeService {
	
	@Autowired
	private EmployeRepository repo;
	
	@Autowired
	private EmployeMapper mapper;
	
	private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);

	public EmployeDto creating(EmployeDto dto) {
		dto.setPassword(encoder.encode(dto.getPassword()));
		Employe emp=mapper.toDto(dto);
		Employe employe=repo.save(emp);
		return mapper.toEntity(employe);
	}

	public List<EmployeDto> gettingAll() {
		List<Employe> emp=repo.findAll();
		return mapper.toList(emp);
	}

	public EmployeDto gettingId(Long id) {
		Employe emp=repo.findById(id).orElseThrow(()->new RuntimeException("Not Available"));
		return mapper.toEntity(emp);
	}

	public EmployeDto updating(Long id, EmployeDto dto) {
		Employe emp=repo.findById(id).orElseThrow(()->new RuntimeException("Not Available"));
		emp.setFname(dto.getFname());
		emp.setLname(dto.getLname());
		emp.setSalary(dto.getSalary());
		Employe saved=repo.save(emp);
		return mapper.toEntity(saved);
	}

	public void deleting(Long id) {
		if(id==null) {
			
		}
		repo.deleteById(id);
	}

}
