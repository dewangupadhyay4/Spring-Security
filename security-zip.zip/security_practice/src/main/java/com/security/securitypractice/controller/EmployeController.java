package com.security.securitypractice.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.security.securitypractice.dto.EmployeDto;

public interface EmployeController {
	
	public ResponseEntity<EmployeDto> create(EmployeDto dto);
	
	public ResponseEntity<List<EmployeDto>> getAllOnce();
	
	public ResponseEntity<EmployeDto> getOne(Long id);
	
	public ResponseEntity<EmployeDto> update(Long id,EmployeDto dto);
	
	public void delete(Long id);

}
