package com.security.securitypractice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.security.securitypractice.dto.EmployeDto;
import com.security.securitypractice.entity.Employe;

@Component
public class EmployeMapper {
	
	public static Employe toDto(EmployeDto dto) {
		Employe employe=new Employe();
		employe.setId(dto.getId());
		employe.setFname(dto.getFname());
		employe.setLname(dto.getLname());
		employe.setSalary(dto.getSalary());
		employe.setUsername(dto.getUsername());
		employe.setPassword(dto.getPassword());
		return employe;
	}
	
	public static EmployeDto toEntity(Employe employe) {
		EmployeDto dto=new EmployeDto();
		dto.setId(employe.getId());
		dto.setFname(employe.getFname());
		dto.setLname(employe.getLname());
		dto.setSalary(employe.getSalary());
		dto.setUsername(employe.getUsername());
		dto.setPassword(employe.getPassword());
		return dto;
	}
	
	public static List<EmployeDto> toList(List<Employe> employe){
		List<EmployeDto> list=new ArrayList<>();
		for(Employe emp:employe) {
			list.add(toEntity(emp));
		}
		return list;
	}

}
