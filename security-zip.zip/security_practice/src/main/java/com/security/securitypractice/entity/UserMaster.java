package com.security.securitypractice.entity;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UserMaster implements UserDetails{
	
	private Employe employe;
	
	public UserMaster(Employe employe) {
		this.employe=employe;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singleton(new SimpleGrantedAuthority("User"));
	}

	@Override
	public String getPassword() {
		return employe.getPassword();
	}

	@Override
	public String getUsername() {
		return employe.getUsername();
	}

}
